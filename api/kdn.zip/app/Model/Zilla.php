<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Zilla extends Model
{
    protected $fillable = ['country_id','name'];
}
