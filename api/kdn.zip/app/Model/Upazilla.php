<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Upazilla extends Model
{
    protected $fillable = ['name','district_id'];
}
