<nav class="nav flex-column" style="border: 1px solid #eeeeee">
    <a class="nav-link nav-expo" href="{{route('admin-home')}}">Dashboard</a>
    <a class="nav-link nav-expo" href="{{url('/admin/admins')}}">Admins</a>
    <a class="nav-link nav-expo" href="{{url('/admin/users')}}">Users</a>
    <a class="nav-link nav-expo" href="{{url('/admin/blood-request')}}">Blood Request</a>
    <a class="nav-link nav-expo" href="{{url('/admin/country')}}">Country</a>
    <a class="nav-link nav-expo" href="{{url('/admin/zilla')}}">Zilla</a>
    <a class="nav-link nav-expo" href="{{url('/admin/upazilla')}}">Upazilla</a>
    <a class="nav-link nav-expo" href="{{url('/admin/donors')}}">Donors</a>
    <a class="nav-link nav-expo" href="{{url('/admin/readydonors')}}">Ready Donor</a>
    <a class="nav-link nav-expo" href="{{url('/admin/coordinators')}}">Coordinators</a>
    <a class="nav-link nav-expo" href="{{url('/admin/organization')}}">Organization</a>
    <a class="nav-link nav-expo" href="{{url('/admin/blood-bank')}}">Blood Bank</a>
</nav>
